import Cocoa

class  Animal {
    
    var legs : Int
    
    init (legs: Int) {
        self.legs = legs
    }
    
    
    
}

class Dog : Animal {
    
    var name : String
    init (name: String) {
        self.name = name
        super.init(legs: 4)
    }
    
    func speak() {
        print("I am \(name), barking walf walf!")
    }
    
}


class Corgi : Dog {
    let iq : Int = 75
    
    override init(name: String) {
        super.init(name: name)
    }
    
    override func speak() {
        print("I am Corgi, I have IQ of \(iq), Woof woof!")
    }
}

class Poodle : Dog {
    let iq : Int = 96
    
    override init(name: String) {
        super.init(name: name)
    }
    
    override func speak() {
        print("I am Corgi, I have IQ of \(iq), Woof woof!")
    }
}

class Cat : Animal {
    
    var name : String
    var isTamed: Bool
    init (name: String, isTamed: Bool) {
        self.name = name
        self.isTamed = isTamed
        super.init(legs: 4)
    }
    
    func speak() {
        print("I am \(name), meow~~~~~~!")
    }
}

class Persian : Cat {
    override init(name: String, isTamed: Bool) {
        super.init(name: name, isTamed: isTamed)
    }
    
    override func speak() {
        print(" I am persian cat")
    }
}

class Lion : Cat {
    override init(name: String, isTamed: Bool) {
        super.init(name: name, isTamed: isTamed)
    }
    
    override func speak() {
        print("Roar!")
    }
}
let mycat = Cat(name: "Japa", isTamed: true)
mycat.speak()

let mylion = Lion(name: "Leo", isTamed: true)
mylion.speak()
