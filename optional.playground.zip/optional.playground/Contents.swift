import Cocoa

// optionals

let opposites = ["Mario":"Wario", "Luigi":"Waluigi"]
let peachOpposite = opposites["Peach"]

print(peachOpposite)


if let marioOpposite = opposites["Mario"] {
    print("Mario's opposite is \(marioOpposite)")
}


var username : String? = nil

if let unwrappedName = username {
    print("We got a user \(unwrappedName)")
} else {
    print("The optional was empty")
}

var a : String? = nil

if let b = a {
    print("someting's there")
} else {
    print("nothing")
}


func printSquare(of number: Int?) {
    guard let unwrapped = number else {
        print("missing input")
        return
    }
    
    print("Value is \(unwrapped)")
}


let num : Int? = 10

printSquare(of: num)


let captains = [
    "Enterprise": "Picard",
    "Voyger": "Janeway",
    "Defiant": "Sisco"

]


let new = captains["Serenity"] ?? "Not Avail"

print(new)


enum UserError : Error {
    case badID, networkFailed
}


func getUser(id: Int) throws -> String {
    throw UserError.networkFailed
}

if let user = try? getUser(id: 33) {
    print("user : \(user)")
}

func takingRandomArrays(numbers : [Int]?) -> Int {
    
    numbers?.randomElement() ?? Int.random(in: 1...100)
}

let myrr = [1,2,3,4,12,4,123,4,21,21,22]

for i in 1...100 {
    print(takingRandomArrays(numbers: myrr))
}

