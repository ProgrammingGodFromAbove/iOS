import Cocoa

// protocol



protocol Vehicle {
    func estimateTime(for distance: Int) -> Int
    func travel(distance : Int)
}

struct Car : Vehicle {
    func estimateTime(for distance: Int) -> Int {
        distance / 50
    }
    func travel(distance: Int) {
        print("I am traveling \(distance) kilo meters")
    }
    func openSunroof() {
        print("It's a nice day")
    }
}

func commute(distance: Int, using vehicle: Car) {
    if vehicle.estimateTime(for: distance) > 100 {
        print("That's too slow")
    } else {
        vehicle.travel(distance: distance)
    }
}

protocol Building {
    
    var numberOfRooms : Int { get }
    var cost : Int  { get }
    var estateAgentName : String { get }
    
    func printSalesSummary()
}



struct House: Building {
    var numberOfRooms: Int
    var cost: Int
    var estateAgentName: String
    
    func printSalesSummary() {
        print("House for sale: \(numberOfRooms) rooms, price: \(cost), agent: \(estateAgentName)")
    }
}


struct Office: Building {
    var numberOfRooms: Int
    var cost: Int
    var estateAgentName: String
    
    func printSalesSummary() {
        print("Office space for sale: \(numberOfRooms) rooms, price: \(cost), agent: \(estateAgentName)")
    }
}

let myHouse = House(numberOfRooms: 5, cost: 300000, estateAgentName: "Jane Doe")
myHouse.printSalesSummary()

let myOffice = Office(numberOfRooms: 10, cost: 500000, estateAgentName: "John Smith")
myOffice.printSalesSummary()
